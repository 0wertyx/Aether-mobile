# AETHER Android · 0.1.0-mobile

Android-порт интерфейса из `AETHER_Build(2).zip` (WPF/WebView2) с наложенным `AETHER_Interface_Patch.zip`. Это отдельная ветка интерфейса, не изменение Windows EXE, не Tauri-версия и не инжектор. Исходные HTML, CSS, JS, иконки и ресурсы из предоставленного архива сохранены; Windows-библиотеки не входят в проект.

## Сборка

- Android Studio с Android SDK Platform 35 и Build Tools 34.0.0.
- JDK 17, Gradle 8.9, Android Gradle Plugin 8.7.3.
- minSdk 26 (Android 8.0), targetSdk 35. Требуется актуальный Android System WebView (современные JS/CSS API).
- Интернет нужен для первой загрузки зависимостей и Google Fonts, не для симулятора.

Распакуйте архив и откройте корневой каталог `AETHER-Android` в Android Studio. После Gradle Sync: **Build > Build APK(s)** или в терминале с установленным Gradle 8.9:

```sh
gradle --no-daemon :app:assembleDebug
```

Результат: `app/build/outputs/apk/debug/app-debug.apk`. При необходимости на машине с Gradle можно создать wrapper: `gradle wrapper --gradle-version 8.9`, затем `gradlew.bat :app:assembleDebug` на Windows или `./gradlew :app:assembleDebug` на Linux/macOS. Wrapper JAR не включён, поскольку в текущей среде Gradle отсутствует. Debug APK будет подписан стандартным локальным debug-ключом; релизный ключ не создавался. В `.github/workflows/android.yml` предусмотрен вручную запускаемый CI build, если проект будет помещён в отдельный GitHub-репозиторий; workflow не запускался.

## Что перенесено

- Телефон: нижняя панель из 5 кнопок и дополнительное меню для Indicators, Lua Studio, Developer; планшет: боковая навигация; широкие экраны: двухколоночная компоновка. Исходная палитра AETHER, glassmorphism и оригинальные иконки.
- HUD-симулятор, HP/часы, визуальные индикаторы, редактирование расположения в локальном preview, анимации и внешний вид.
- Font Studio и Interface Appearance, 4 варианта встроенного шрифта, открытие и переходы (Disabled/Fade/Slide up/Soft zoom, 0.5–2×), локальные настройки. Исходный каталог Google Fonts и новый IndexedDB-кэш; скачивание не проверено.
- World FX, 16 атмосферы-пресетов, Workshop/Asset Library, Cursor Studio (локальный preview, мышь/стилус), Lua Studio (исходный изолированный Lua worker), локальная диагностика, профили и сохранение настроек.
- Android Activity с WebViewAssetLoader, HTTPS origin для локальных assets, SAF picker для импорта и экспорта, обработка системного Back, ориентации, клавиатуры и системных insets. Не выдаются разрешения на наложение поверх других приложений, root, доступ к чужим процессам или общему хранилищу.

## Отличия и ограничения

- Первичные значения профиля реконструированы по HTML/JS, поскольку нативный Windows-источник в архиве отсутствует. Старые Windows профили не мигрируют автоматически.
- Windows WebView2 bridge заменён на JS-host с localStorage/IndexedDB. Отсутствующий desktop HUD и live Studio relay не симулируются как работающие; соответствующие варианты отключены. Roblox Studio Companion и установщик/автообновление Windows не портированы. Нативный Luau compiler отсутствует: проверка Luau в Android возвращает явную ошибку; исходный AETHER Lua worker сохранён. Нет внешнего игрового оверлея.
- Native file chooser, Google Fonts, Lua worker, touch-жесты, Android back и rotation требуют теста на реальном устройстве. Логи в памяти с экспортом, не постоянный Windows log file.

## Верификация

`node --experimental-default-type=module tests/host.mjs` — PASS: настройки, проверка диапазонов и значений, сохранение/загрузка/удаление профиля, источник симулятора, явные ошибки отсутствующих операций, диагностика, нормализация анимаций, наличие каталога и покрытие полей HTML. Все 26 JS-модули/скрипты прошли `node --input-type=module --check`; XML синтаксически разобран. Это проверки кода, не подтверждение работоспособности Android.

`python tests/smoke.py` — тесты Chromium/Playwright для 360, 412, 800, 1280 px подготовлены; попытка запуска в текущей среде остановилась на первом `ERR_BLOCKED_BY_ADMINISTRATOR` при открытии localhost, остальные UI-проверки не выполнены. Для локального запуска нужны Python, Playwright, Chromium; путь Chromium можно адаптировать в тесте.

APK не собран, нативный Java-код не скомпилирован, не установлен и не runtime-tested: Android SDK/Gradle в текущей среде отсутствуют. GitHub и исходный Windows архив не изменены.
