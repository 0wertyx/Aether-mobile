from pathlib import Path
from functools import partial
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from threading import Thread
from playwright.sync_api import sync_playwright
root = Path(__file__).resolve().parents[1] / 'app/src/main/assets/web'
class Handler(SimpleHTTPRequestHandler):
    def log_message(self,*args): pass
server=ThreadingHTTPServer(('127.0.0.1',0),partial(Handler,directory=str(root)))
Thread(target=server.serve_forever,daemon=True).start()
url=f'http://127.0.0.1:{server.server_port}/index.html'
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage','--no-proxy-server'])
    for width,height in [(360,800),(412,915),(800,1280),(1280,800)]:
        ctx=browser.new_context(viewport={'width':width,'height':height},is_mobile=width<760,has_touch=True)
        page=ctx.new_page(); errors=[]; page.on('pageerror',lambda e:errors.append(str(e)))
        page.goto(url,wait_until='domcontentloaded'); page.wait_for_function("document.documentElement.dataset.ready==='true'",timeout=12000)
        page.locator('#damage').click(); page.wait_for_timeout(400); assert page.locator('#sim-hp-value').inner_text()=='75'
        page.locator('#respawn').click(); assert page.locator('#sim-hp-value').inner_text()=='100'
        for key in ['fonts','world','workshop','indicators','scripts','developer','dashboard']:
            if width<760 and key in ['indicators','scripts','developer']:
                page.locator('.mobile-more').click(); page.locator(f'#mobile-extra [data-tab={key}]').click()
            else: page.locator(f'#nav > [data-tab={key}]').click()
            page.wait_for_timeout(350); assert page.locator(f'#{key}').evaluate("x=>x.classList.contains('active')"),key
            overflow=page.evaluate('document.documentElement.scrollWidth - innerWidth'); assert overflow<=2,(width,key,overflow)
        page.locator('[data-setting=accent]').evaluate("e=>{e.value='#ff88aa';e.dispatchEvent(new Event('change'))}")
        page.wait_for_timeout(100);page.reload(wait_until='domcontentloaded');page.wait_for_function("document.documentElement.dataset.ready==='true'");assert page.locator('[data-setting=accent]').input_value()=='#ff88aa'
        assert not errors,errors
        print(f'PASS {width}×{height}: boot, simulator, 7 tabs, no horizontal overflow, persistence')
        if width==412: page.screenshot(path='/mnt/data/AETHER-Android-preview.png')
        ctx.close()
    browser.close()
server.shutdown()
